﻿namespace niconico
{
    partial class taskicon
    {
        /// <summary>
        /// 必要なデザイナー変数です。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// 使用中のリソースをすべてクリーンアップします。
        /// </summary>
        /// <param name="disposing">マネージ リソースを破棄する場合は true を指定し、その他の場合は false を指定します。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region コンポーネント デザイナーで生成されたコード

        /// <summary>
        /// デザイナー サポートに必要なメソッドです。このメソッドの内容を
        /// コード エディターで変更しないでください。
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(taskicon));
            this.notifyIcon1 = new System.Windows.Forms.NotifyIcon(this.components);
            this.contextMenuStrip1 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.toolStripMenu_Open = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenu_Exit = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenu_Stop = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenu_Resume = new System.Windows.Forms.ToolStripMenuItem();
            this.contextMenuStrip1.SuspendLayout();
            // 
            // notifyIcon1
            // 
            this.notifyIcon1.ContextMenuStrip = this.contextMenuStrip1;
            this.notifyIcon1.Icon = ((System.Drawing.Icon)(resources.GetObject("notifyIcon1.Icon")));
            this.notifyIcon1.Text = "MoriMoriControl";
            this.notifyIcon1.Visible = true;
            // 
            // contextMenuStrip1
            // 
            this.contextMenuStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.contextMenuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenu_Open,
            this.toolStripMenu_Exit,
            this.toolStripMenu_Stop,
            this.toolStripMenu_Resume});
            this.contextMenuStrip1.Name = "contextMenuStrip1";
            this.contextMenuStrip1.Size = new System.Drawing.Size(139, 100);
            // 
            // toolStripMenu_Open
            // 
            this.toolStripMenu_Open.Name = "toolStripMenu_Open";
            this.toolStripMenu_Open.Size = new System.Drawing.Size(138, 24);
            this.toolStripMenu_Open.Text = "表示";
            // 
            // toolStripMenu_Exit
            // 
            this.toolStripMenu_Exit.Name = "toolStripMenu_Exit";
            this.toolStripMenu_Exit.Size = new System.Drawing.Size(138, 24);
            this.toolStripMenu_Exit.Text = "終了";
            // 
            // toolStripMenu_Stop
            // 
            this.toolStripMenu_Stop.Name = "toolStripMenu_Stop";
            this.toolStripMenu_Stop.Size = new System.Drawing.Size(138, 24);
            this.toolStripMenu_Stop.Text = "一時停止";
            // 
            // toolStripMenu_Resume
            // 
            this.toolStripMenu_Resume.Name = "toolStripMenu_Resume";
            this.toolStripMenu_Resume.Size = new System.Drawing.Size(138, 24);
            this.toolStripMenu_Resume.Text = "再開";
            this.contextMenuStrip1.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.NotifyIcon notifyIcon1;
        private System.Windows.Forms.ContextMenuStrip contextMenuStrip1;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenu_Open;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenu_Exit;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenu_Stop;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenu_Resume;
    }
}
